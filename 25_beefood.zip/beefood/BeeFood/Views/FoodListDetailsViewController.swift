//
//  FoodListDetailsViewController.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

class FoodListDetailsViewController: UIViewController{
    
    @IBOutlet weak var ratingLabel: UILabel!
    
    @IBOutlet weak var queueTimeLabel: UILabel!
    
    @IBOutlet weak var halalImage: UIImageView!
    
    
    var data: MerchantModel!{
        didSet{
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }

                if let rating = self.data?.rating {
                    self.ratingLabel.text = "\(rating)"
                }

                if let queueTime = self.data?.queueTime {
                    self.queueTimeLabel.text = "\(queueTime)m"
                }

                if let isHalal = self.data?.halal {
                    self.halalImage.image = isHalal ? UIImage(named: "halal") : UIImage(systemName: "xmark.circle.fill")
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}


