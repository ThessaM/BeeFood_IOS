//
//  FoodListTableViewCell.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

class FoodListTableViewCell: UITableViewCell {
    
    
    //delegate data passing
    weak var delegate: TableViewDelegate?
    
    
    @IBOutlet weak var foodImage: UIImageView!
    
    @IBOutlet weak var foodNameLabel: UILabel!
    
    @IBOutlet weak var foodDescLabel: UILabel!
    
    @IBOutlet weak var foodPriceLabel: UILabel!
    
    @IBOutlet weak var foodQtyLabel: UILabel!
    
    @IBOutlet weak var stepper: UIStepper!
    

    
    @IBAction func qtyStepper(_ sender: UIStepper) {
        
        let newQty = Int(sender.value)
        foodQtyLabel.text = "Qty: \(newQty)"
        
        if let data = productInd {
            delegate?.didSelectItem(withData: data, qty: newQty)
        }
    }
    
    var productInd:Int?
    var merchantId: String?
    
    var foodItem:MenuModel!{
        didSet{
            foodImage.image = foodItem.thumbnailPicture
            foodNameLabel.text = foodItem.name
            foodDescLabel.text = foodItem.description
            foodPriceLabel.text = "Rp. \(foodItem.price)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

protocol TableViewDelegate: AnyObject {
    func didSelectItem(withData ind: Int, qty: Int)
}
