//
//  OrderDetailsTableViewCell.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

class OrderDetailsTableViewCell: UITableViewCell {

    
    @IBOutlet weak var orderQtyAndNameLabel: UILabel!
    
    @IBOutlet weak var totalPricePerItemLabel: UILabel!
    
    
    func setLabels(qtyName:String, price:Int){
        orderQtyAndNameLabel.text = qtyName
        totalPricePerItemLabel.text = "Rp. \(price)"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
