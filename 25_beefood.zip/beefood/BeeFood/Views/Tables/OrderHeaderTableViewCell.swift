//
//  OrderHeaderTableViewCell.swift
//  BeeFood
//
//  Created by prk on 11/12/23.
//

import UIKit

class OrderHeaderTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var merchantNameLabel: UILabel!
    
    @IBOutlet weak var merchantLocationLabel: UILabel!
    
    @IBOutlet weak var merchantCampusLabel: UILabel!
    
    
    @IBOutlet weak var orderStatusImage: UIImageView!
    
    
    var curStatus: Int!{
        didSet{
            if(curStatus == 1){
                //waiting - Order Status-1
                orderStatusImage.image = UIImage(named: "Order Status-1")
            }else if(curStatus == 2){
                //on process  Order Status-3
                orderStatusImage.image = UIImage(named: "Order Status-3")
            }else if(curStatus == 3){
                //ready  Order Status-2
                orderStatusImage.image = UIImage(named: "Order Status-2")
            }
        }
    }
    
    
    var merchant:MerchantModel!{
        didSet{
            merchantNameLabel.text = merchant.name
            merchantLocationLabel.text = merchant.location
            merchantCampusLabel.text = "@\(merchant.campus)"
        }
    }
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
