//
//  PickUpViewController.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

protocol confirmPickUpDelegate: AnyObject{
    func didOrderStatusUpdated()
}

class PickUpViewController: UIViewController {

    weak var pickUpDelegate: confirmPickUpDelegate?
    
    
    //TOP VIEW
    
    
    @IBAction func backButtonOnPressed(_ sender: Any) {
        backToHomeTabBar()
    }
    
    func backToHomeTabBar(){
        if let homeViewController = navigationController?.viewControllers.first(where: { $0 is UITabBarController }) {
            navigationController?.popToViewController(homeViewController, animated: true)
        }else{
            print("CONTROLLER NOT FOUND")
        }
    }
    
    
    
    //TABLEVIEW ---------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var pickUpTableView: UITableView!
    
    
    //BOTTOM VIEW  ---------------------------------------------------------------------------------------------------
    
    
    
    @IBOutlet weak var totalPriceLabel: UILabel!
    
    @IBAction func confirmPickUpOnClick(_ sender: Any) {
        
        let alert = UIAlertController(title: "Warning", message: "Make sure you have pickup your food before continuing", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Continue", style: .default) {
            (action) in
            //update status di firebase + history
            FirebaseService.shared.updateOrderStatus(orderId: self.order.id, newStatus: 4) { updateError in
                if let updateError = updateError{
                    print("Update Error: \(updateError)")
                }else{
                    self.pickUpDelegate?.didOrderStatusUpdated()
                    GlobalData.shared.sendMessageFCM(merchantToken: self.merchant.FCMToken, notifTitle: "Order Finished", notifBody: "User has picked-up the food.")
                    print("FCM SEND")
                }
            }
            
            self.backToHomeTabBar()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
        
        
        
    }
    
    var merchant: MerchantModel!
    var order: OrderModel!

    
    //VIEW DID LOAD ---------------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        totalPriceLabel.text = "Rp. \(order.totalPrice)"
        pickUpTableView.dataSource = self
        pickUpTableView.delegate = self
        
    }
    
    
}


extension PickUpViewController: UITableViewDataSource, UITableViewDelegate{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return order.cartItems.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var ident:String
        
        if(indexPath.row == 0){
            ident = "orderHeaderCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: ident, for: indexPath) as! OrderHeaderTableViewCell
            cell.merchant = merchant
            cell.curStatus = order.status
            
            return cell
        }else{
            ident = "orderDetailsCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: ident, for: indexPath) as! OrderDetailsTableViewCell
            let curOrderItem = merchant.product.first { merchProd in
                merchProd.id == order.cartItems[indexPath.row-1].menuId
            }
            let orderQty = order.cartItems[indexPath.row-1].qty
            let itemName = curOrderItem?.name ?? "N/A"
            cell.setLabels(qtyName: "\(orderQty) x \(itemName)", price: curOrderItem!.price*orderQty)
            return cell
        }
    
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.row == 0){
            return 365
        }
        
        return 44
    }
    
}
