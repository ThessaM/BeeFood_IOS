//
//  RegisterViewController.swift
//  BeeFood
//
//  Created by prk on 10/30/23.
//

import UIKit
import Firebase
import FirebaseFirestore

class RegisterViewController: UIViewController {
    
    
    @IBOutlet weak var nameField: FloatingLabelInput!
    @IBOutlet weak var emailField: FloatingLabelInput!
    @IBOutlet weak var binusianIdField: FloatingLabelInput!
    @IBOutlet weak var passwordField: FloatingLabelInput!
    
    
    //REGISTER BTN --------------------------------------------------------------------------------------------------------------------------------
    
    @IBAction func registerBtnOnPressed(_ sender: Any) {
        let name = nameField.text!
        let email = emailField.text!
        let binusianId = binusianIdField.text!
        let password = passwordField.text!
        
        
        
        //validation
        if(name.isEmpty || email.isEmpty || binusianId.isEmpty || password.isEmpty){
            validationAlert(valMsg: "All field must be filled")
            return
        }else if(!(email.hasSuffix("@binus.ac.id") || email.hasSuffix("@binus.edu"))){
            validationAlert(valMsg: "Please use your binusian email (@binus.ac.id or @binus.edu)")
            return
        }else if(!validatePass(pass: password)){
            validationAlert(valMsg: "Password must be alphanumeric: a-z/ A-Z, 0-9")
            return
        }else if(password.count < 5){
            validationAlert(valMsg: "Password must be 6 characters long or more")
        }
        
        //post validation
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error creating user: \(error.localizedDescription)")
                return
            }

            // User successfully created
            guard let uid = authResult?.user.uid else { return }

            // Additional user data
            let userData = [
                "name": name,
                "email": email,
                "binusianID": binusianId,
                "profilePicture": "",
                "FCMToken": GlobalData.deviceFCMToken
            ]

            // Store additional data in Firestore
            let db = Firestore.firestore()
            db.collection("user").document(uid).setData(userData) { error in
                if let error = error {
                    print("Error storing user data: \(error.localizedDescription)")
                    return
                }
                // User data stored successfully
                print("DATA SAVED SUCCESSFULLY")
                
                let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
                
                
                FirebaseService.shared.fetchUserFromFirestoreByUid(uid: uid) { userData, userError in
                    if let userError = userError{
                        print("Error fetching user data: \(userError)")
                    }else{
                        //kalo udh selesai ambil data
                        self.navigationController?.pushViewController(dest, animated: true)
                    }
                }
                
            }
        }
        
    }
    
    func validatePass(pass: String) -> Bool{
        var isLet = false
        var isNum = false
        
        pass.forEach { c in
            if c.isLetter{
                isLet = true
            }else if c.isNumber{
                isNum = true
            }
        }
        
        return isLet && isNum
        
    }
    
    //ALERT
    func validationAlert(valMsg: String){
        let alert = UIAlertController(title: "Warning", message: valMsg, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .default)
        
        alert.addAction(action)
        present(alert, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
  
}
