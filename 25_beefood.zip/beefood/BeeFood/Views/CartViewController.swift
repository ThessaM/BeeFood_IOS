//
//  CartViewController.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit
import FirebaseFirestore
import FirebaseMessaging


protocol cartOrderAddedDelegate: AnyObject{
    func didHistoryOrderDataUpdated()
}


class CartViewController: UIViewController, TableViewDelegate, ChoosePaymentControllerDelegate{
    
    
    weak var cartDelegate: cartOrderAddedDelegate?
    
    //TOP VIEW ------------------------------------------------------------------------------------------------------------------------------
    
    var merchant:MerchantModel?
    var buyProducts:[MenuModel]?
    
    @IBAction func backButtonOnClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBOutlet weak var timeEstimationLabel: UILabel!
    
    @IBOutlet weak var pickUpField: UITextField!
    
    
    let timePicker = UIDatePicker()
    
    func createTimePicker() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: false)

        pickUpField.inputAccessoryView = toolbar

        timePicker.datePickerMode = .time
        pickUpField.inputView = timePicker

        timePicker.frame = CGRect(x: view.bounds.width/2, y: 100, width: view.bounds.width, height: 200)
    }


    @objc func donePressed() {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        pickUpField.text = formatter.string(from: timePicker.date)
        self.view.endEditing(true)
    }
    
    @IBAction func addMoreOnClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    //TABLE VIEW ------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var foodListTableView: UITableView!
    
    
    func didSelectItem(withData ind:Int, qty: Int) {
        
        let existingCartItem = GlobalData.curCart.cartItems[ind]
        
        let curProduct = merchant!.product.first{
            item in item.id == existingCartItem.menuId
        }
        

        //update cart, add qty or remove qty and adjust to remove from cart if qty hits 0
        existingCartItem.qty = qty
        if(qty == 0){
            GlobalData.curCart.cartItems.removeAll { item in
                item.menuId == curProduct!.id && item.qty == 0
            }
            foodListTableView.reloadData()
            
        }
        
        if(GlobalData.curCart.cartItems.isEmpty){
            navigationController?.popViewController(animated: true)
        }
        
        updatePriceLabel()
    }
    
    //BOTTOM VIEW ------------------------------------------------------------------------------------------------------------------------------
    
    
    @IBOutlet weak var paymentMethodButton: UIButton!
    
    @IBAction func paymentMethodOnClick(_ sender: Any) {
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChoosePaymentViewController") as! ChoosePaymentViewController
        dest.paymentDelegate = self
        navigationController?.pushViewController(dest, animated: true)
    }
    
    func didPaymentSelected(_ reuseIdentifier: String?) {
        paymentMethodButton.setTitle(reuseIdentifier, for: .normal)
    }
    
    @IBOutlet weak var totalPriceLabel: UILabel!
    
    
    func updatePriceLabel(){
        let total = countTotalPrice()
        totalPriceLabel.text = "Rp. \(total)"
    }
    
    @IBAction func orderButtonOnClick(_ sender: Any) {
        
//        validation
        
        if(pickUpField.text?.isEmpty ?? true ){
            cartAlert(alertMsg: "Pick up time field is empty")
            return
        }else if (paymentMethodButton.titleLabel?.text?.elementsEqual("Select Payment Method") ?? true){
            cartAlert(alertMsg: "Please Select a payment method first")
            return
        }
        
        //validate time
        let currentDate = Date()
        let minPickUpTime = currentDate.addingTimeInterval(Double(merchant!.queueTime * 60))
        if(timePicker.date < minPickUpTime){
            cartAlert(alertMsg: "The pick up time is not avaliable, please choose longer interval")
            return 
        }
        
        
        sendMessageFCM()
        
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PickUpViewController") as! PickUpViewController
        let newOrder = createOrder()

        dest.order = newOrder
        dest.merchant = merchant
        navigationController?.pushViewController(dest, animated: true)
    }
    
    func createOrder() -> OrderModel {
        let total = countTotalPrice()

        guard let merchantId = merchant?.id else {
            fatalError("Merchant ID is nil.")
        }

        let formatter = DateFormatter()
        formatter.timeStyle = .short

        guard let paymentMethod = paymentMethodButton.titleLabel?.text else {
            fatalError("Payment method is nil.")
        }
        
        let order = OrderModel(
            id: "",
            userId: GlobalData.curUser!.id,
            merchantId: merchantId,
            cartItems: GlobalData.curCart.cartItems,
            payment: paymentMethod,
            totalPrice: total,
            status: 1,
            pickUpTime: formatter.string(from: timePicker.date),
            createTime: formatter.string(from: Date.now)
        )
        
        //add to firebase
        let orderData = [
            "createTime": Date.now,
            "merchantReferenceID": merchantId,
            "payment": paymentMethod,
            "pickupTime": timePicker.date,
            "status": 1,
            "totalPrice": total,
            "userReferenceID": GlobalData.curUser!.id
        ] as [String: Any]

        // Store data in Firestore
        let db = Firestore.firestore()
        
        let orderReference = db.collection("order").document()
        
        orderReference.setData(orderData) { error in
            if let error = error {
                print("Error storing order data: \(error.localizedDescription)")
                return
            }
            
            
            for cartItem in GlobalData.curCart.cartItems {
                let subcollectionData = [
                    "productReferenceID": cartItem.menuId,
                    "quantity": cartItem.qty
                ]

                // Add subcollection to the main document
                orderReference.collection("orderItems").addDocument(data: subcollectionData) { subcollectionError in
                    if let subcollectionError = subcollectionError {
                        print("Error storing subcollection data: \(subcollectionError.localizedDescription)")
                        // Handle error if needed
                    } else {
                        // Subcollection data stored successfully
                        print("SUBCOLLECTION DATA SAVED SUCCESSFULLY")
                        //update history table
                        self.cartDelegate?.didHistoryOrderDataUpdated()
                        NotificationCenter.default.post(name: .orderAddedFromCart, object: self)
                    }
                }
            }

            // data stored successfully
            print("ORDER DATA SAVED SUCCESSFULLY")
            
            //delete item in cart
            GlobalData.curCart.cartItems.removeAll()
        }
        
        

        return order
    }
    
    func cartAlert(alertMsg:String){
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default)
        alert.addAction(action)
        present(alert, animated: true)
    }
    
    func countTotalPrice() -> Int{
        var total = 0;
        GlobalData.curCart.cartItems.forEach { cartItem in
            let curProd = merchant?.product.first(where: { prodItem in
                cartItem.menuId == prodItem.id
            })
            total += curProd!.price * cartItem.qty
        }
        return total
    }
    
    
    
    //VIEW DID LOAD ------------------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Top View
        timeEstimationLabel.text = "\(merchant!.queueTime) min"
        createTimePicker()
        
        //Food Table
        foodListTableView.dataSource = self
        
        //bottom view
        updatePriceLabel()
        
    }
    
    
    //FCM MESSAGING ---------------------------------------------------------------------------------------------------------------------
    func sendMessageFCM(){
        let serverKey = "AAAAaOhAJzA:APA91bGVZP53NZtJXgsZPjEGFxgjQj3Gevs2SQRBOjKRqFdJaH6E7UII_hQ6yUPmd2JqMSn8gZAOvSpeAFeVbeEv3s4Sbsww9c5U079zkvuUMNSLDmy7baHU9GqohNPEYNEIUdAITl1K"
        let fcmToken = merchant?.FCMToken

        let url = URL(string: "https://fcm.googleapis.com/fcm/send")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("key=\(serverKey)", forHTTPHeaderField: "Authorization")

        let body: [String: Any] = [
            "to": fcmToken as Any,
            "notification": [
                "title": "New Order Received",
                "body": "\(GlobalData.curUser!.name) has just placed an order."
            ]
            ,
//            "data": [
//                "key1": "value1",
//                "key2": "value2"
//            ]
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle the response
            if let error = error{
                print("MESSAGE ERROR: \(error)")
            }else{
                print("MESSAGE SUCCESS: \(String(describing: response))")
            }
        }.resume()
    }

}



extension CartViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return GlobalData.curCart.cartItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartCell", for: indexPath) as! FoodListTableViewCell
        
        cell.delegate = self
        
        let curItem = GlobalData.curCart.cartItems[indexPath.row]
        
        let curFood = merchant?.product.first(where: { item in
            item.id == curItem.menuId
        })
        
        cell.foodItem = curFood
        
        cell.stepper.value = Double(curItem.qty)
        cell.foodQtyLabel.text = "Qty: \(curItem.qty)"
        
        
        cell.productInd = indexPath.row
        
        return cell
    }
    
}
