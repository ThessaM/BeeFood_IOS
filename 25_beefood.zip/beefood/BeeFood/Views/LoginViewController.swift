//
//  LoginViewController.swift
//  BeeFood
//
//  Created by prk on 10/30/23.
//

import UIKit
import Firebase
import FirebaseFirestore

class LoginViewController: UIViewController {
    
    
    //LOGIN BTN
    
    @IBOutlet weak var emailField: FloatingLabelInput!
    
    @IBOutlet weak var passwordField: FloatingLabelInput!
    
    
    @IBAction func loginnBtnOnPressed(_ sender: Any) {
        
        let email = emailField.text!
        let password = passwordField.text!
        
        if(email.isEmpty || password.isEmpty){
            let alert = UIAlertController(title: "Warning", message: "All field must be filled", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .default)
            
            alert.addAction(action)
            present(alert, animated: true)
        }
        
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                self.showAlert(alertMsg: "email or password is incorrect")
                print("Error signing in: \(error.localizedDescription)")
                return
            }
            print("SIGN IN SUCCESS")
            
            let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
            
            guard let uid = authResult?.user.uid else { return }
            
            FirebaseService.shared.fetchUserFromFirestoreByUid(uid: uid) { userData, userError in
                if let userError = userError{
                    print("Error fetching user data: \(userError)")
                    self.showAlert(alertMsg: "email or password is incorrect")
                }else{
                    self.navigationController?.pushViewController(dest, animated: true)
                }
            }
        }
    }
    
    func showAlert(alertMsg:String){
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .default)
        
        alert.addAction(action)
        present(alert, animated: true)
    }
    
    
    //REGISTER HERE BTN -----------------------------------------------------------------------------------------------
    
    @IBAction func registerHereBtnOnPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)

        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    

}

