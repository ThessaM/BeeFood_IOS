//
//  FoodListViewController.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

class FoodListViewController: UIViewController, TableViewDelegate {
    
    //NAVIGATION CONTROLLER ---------------------------------------------------------------------------------------------------------------------------
    @IBAction func backButtonOnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    //TOP VIEW --------------------------------------------------------------------------------------------------------------------------------------
    var merchant: MerchantModel!
    
    @IBOutlet weak var merchantNameLabel: UILabel!
    @IBOutlet weak var merchantLocationLabel: UILabel!
    @IBOutlet weak var merchantDetailsView: UIView!
    
     
    //TABLE VIEW  ------------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var foodListTableView: UITableView!
    
    func didSelectItem(withData ind:Int, qty: Int) {
        
        if(merchant.id.elementsEqual(GlobalData.curCart.merchantId) || GlobalData.curCart.cartItems.isEmpty){
            //get current item
            GlobalData.curCart.merchantId = merchant.id
            let curProduct = merchant.product[ind]
            let existingCartItem = GlobalData.curCart.cartItems.first { item in
                item.menuId == curProduct.id
            }

            if let existingCartItem = existingCartItem {
                //update cart, add qty or remove qty and adjust to remove from cart if qty hits 0
                existingCartItem.qty = qty
                if(qty == 0){
                    GlobalData.curCart.cartItems.removeAll { item in
                        item.menuId == curProduct.id && item.qty == 0
                    }
                }
                
            } else {
                // Add new cart if not exist
                let newCartItem = CartItemModel(menuId: curProduct.id, qty: qty)
                GlobalData.curCart.cartItems.append(newCartItem)
            }
        }else{
            showMerchantChangeAlert { [weak self] in
                GlobalData.curCart.cartItems.removeAll()
                GlobalData.curCart.merchantId = self!.merchant.id
                let curProduct = self!.merchant.product[ind]
                let newCartItem = CartItemModel(menuId: curProduct.id, qty: qty)
                GlobalData.curCart.cartItems.append(newCartItem)
                self?.checkCartViewHidden()
            }
        }
        
        //check for any item in cart
        checkCartViewHidden()
    }
    
    func showMerchantChangeAlert(completion: @escaping () -> Void) {
        
        let alertController = UIAlertController(title: "Warning", message: "Changing merchants will empty your cart. Are you sure you want to continue?", preferredStyle: .alert)

        let continueAction = UIAlertAction(title: "Continue", style: .destructive) { _ in
            completion()
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        alertController.addAction(continueAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }
    
    //TO CART VIEW - BOTTOM -------------------------------------------------------------------------------------------------------------------------------
    @IBOutlet weak var cartButtonView: RoundedCornerView!
    
    @IBOutlet weak var itemCountLabel: UILabel!
    @IBOutlet weak var totalPriceLabel: UILabel!
    
    @objc func onCartButtonTapped(){
//        performSegue(withIdentifier: "toCartFromFoodList", sender: self)
        
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
        dest.merchant = merchant
        
        navigationController?.pushViewController(dest, animated: true)
    }
    
    func checkCartViewHidden(){
        
        //get data
        let curCart = GlobalData.curCart
        let merchantProducts = merchant.product
        
        //kalo cart kosong atau merchant nya beda
        if(curCart.cartItems.isEmpty || !curCart.merchantId.elementsEqual(merchant.id)){
            cartButtonView.isHidden = true
        }
        else{
            
            cartButtonView.isHidden = false
            
            var totalPrice = 0;
            var totalQty = 0;
            curCart.cartItems.forEach { cartItm in
                let item = merchantProducts.first { menu in
                    menu.id == cartItm.menuId
                }
                totalPrice += item!.price * cartItm.qty
                totalQty += cartItm.qty
            }
            
            totalPriceLabel.text = "Rp. \(totalPrice)"
            itemCountLabel.text = "\(totalQty) items"
        }
    }
    
    
    
    //VIEW DID LOAD  ------------------------------------------------------------------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //navigation
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        //Top View
        merchantNameLabel.text = merchant.name
        merchantLocationLabel.text = "\(merchant.campus), \(merchant.location)"
        
        
        //food list table view
        foodListTableView.dataSource = self
        
        //to cart view bottom
        checkCartViewHidden()
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(onCartButtonTapped))
        cartButtonView.addGestureRecognizer(gesture)
    }
    
    //PREPARE details UI Container View -------------------------------------------------------------------------------------------------------------------
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Top View - Food List Details
        let ident = segue.identifier
        
        if ident == "FoodListDetails" {
            if let merchDetailsView = segue.destination as? FoodListDetailsViewController {
                merchDetailsView.data = merchant
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        merchant.product.sort(by: {$0.available && !$1.available})
        foodListTableView.reloadData()
        checkCartViewHidden()
    }
    
}

extension FoodListViewController: UITableViewDataSource{
    
    
    //TABLE VIEW  -------------------------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return merchant.product.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "foodListCell", for: indexPath) as! FoodListTableViewCell
        
        cell.delegate = self
        
        let curProduct = merchant.product[indexPath.row]
        cell.foodItem = curProduct
        
        cell.foodQtyLabel.text = "Qty: 0"
        cell.stepper.value = Double(0)
        
        GlobalData.curCart.cartItems.forEach { item in
            if(item.menuId.elementsEqual(curProduct.id)){
                cell.foodQtyLabel.text = "Qty: \(item.qty)"
                cell.stepper.value = Double(item.qty)
            }
        }
        
        cell.productInd = indexPath.row
        
        if(curProduct.available){
            cell.isUserInteractionEnabled = true
            cell.backgroundColor = UIColor.systemBackground
            cell.layer.opacity = 1
        }else{
            cell.isUserInteractionEnabled = false
            cell.backgroundColor = UIColor.systemGray
            cell.layer.opacity = 0.5
        }


        return cell
    }
    
    
}



