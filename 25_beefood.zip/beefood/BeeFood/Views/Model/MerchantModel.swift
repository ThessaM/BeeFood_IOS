//
//  MerchantModel.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class MerchantModel {
    
    var id: String
    var name: String
    var email: String
    var phone: String
    var profilePicture: UIImage
    var description: String
    var campus: String
    var location: String
    var openTime: String
    var closeTime: String
    var halal: Bool
    var rating: Double
    var queueTime: Int
    var product:[MenuModel]
    var FCMToken: String
    
    
    init(id: String, name: String, email: String, phone: String, profilePicture: UIImage, description: String, campus: String, location: String, openTime: String, closeTime: String, halal: Bool, rating: Double, queueTime: Int, product: [MenuModel], FCMToken: String) {
        self.id = id
        self.name = name
        self.email = email
        self.phone = phone
        self.profilePicture = profilePicture
        self.description = description
        self.campus = campus
        self.location = location
        self.openTime = openTime
        self.closeTime = closeTime
        self.halal = halal
        self.rating = rating
        self.queueTime = queueTime
        self.product = product
        self.FCMToken = FCMToken
    }
    
    init?(dataId:String, data: [String: Any], dataImage:UIImage, dataProduct:[MenuModel])
    {
        guard
            let name = data["name"] as? String,
            let email = data["email"] as? String,
            let phone = data["phone"] as? String,
            let description = data["description"] as? String,
            let campus = data["campus"] as? String,
            let location = data["location"] as? String,
            let openTime = data["openTime"] as? String,
            let closeTime = data["closeTime"] as? String,
            let halal = data["halal"] as? Bool,
            let rating = data["rating"] as? Double,
            let queueTime = data["queueTime"] as? Int,
            let FCMToken = data["FCMToken"] as? String
        else{
            return nil
        }
        
        self.id = dataId
        self.name = name
        self.email = email
        self.phone = phone
        self.profilePicture = dataImage
        self.description = description
        self.campus = campus
        self.location = location
        self.openTime = openTime
        self.closeTime = closeTime
        self.halal = halal
        self.rating = rating
        self.queueTime = queueTime
        self.product = dataProduct
        self.FCMToken = FCMToken
    }
    
    static func FetchMerchant() -> [MerchantModel]{
        
        return [
            MerchantModel(id: "0", name: "Xiao Kee Hainam", email: "xiaokee.com", phone: "07375457", profilePicture: UIImage(named: "Merchant-0")!, description: "hainam", campus: "BINUS Kemanggisan", location: "Kantin Payung", openTime: "09.00", closeTime: "17.30", halal: true, rating: 4.3, queueTime: 25, product: MenuModel.FetchMenu2(), FCMToken: "123"),
            MerchantModel(id: "1", name: "Bakmie Effata", email: "effata.com", phone: "07375457", profilePicture: UIImage(named: "Merchant-1")!, description: "mie ayam", campus: "BINUS Kemanggisan", location: "Basement", openTime: "09.00", closeTime: "17.30", halal: true, rating: 4.8, queueTime: 30, product: MenuModel.FetchMenu(), FCMToken: "345"),
            MerchantModel(id: "2", name: "Cerita Cinta", email: "cerita.com", phone: "07375457", profilePicture: UIImage(named: "Merchant-3")!, description: "nasi ayam", campus: "BINUS Kemanggisan", location: "Basement", openTime: "09.00", closeTime: "17.30", halal: true, rating: 4.3, queueTime: 20, product: MenuModel.FetchMenu2(),FCMToken: "3452"),
            MerchantModel(id: "3", name: "Beehive Food Mart", email: "beehive.com", phone: "07375457", profilePicture: UIImage(named: "Merchant-2")!, description: "beehive", campus: "BINUS Kemanggisan", location: "lt. 5", openTime: "09.00", closeTime: "17.30", halal: true, rating: 3.7, queueTime: 35, product: MenuModel.FetchMenu(), FCMToken: "425"),
            MerchantModel(id: "4", name: "Tea Well", email: "tea.com", phone: "07375457", profilePicture: UIImage(named: "Merchant-4")!, description: "teh baik", campus: "BINUS Kemanggisan", location: "Kantin Payung", openTime: "09.00", closeTime: "17.30", halal: true, rating: 4.8, queueTime: 10, product: MenuModel.FetchMenu(), FCMToken: "sfsey997")
        
        ]
    }
    
}




/*
 
 Fetched data: [
 "hILhsdP4ju4HJa6IDwat": ["rating": 4.5, "closeTime": 17:30:00, "name": Xiao Kee Hainam, "queueTime": 30, "description": This is a new merchant., "email": xiaokee.binus@merchant.com, "halal": 1, "phone": +6282846571524, "campus": Kemanggisan Anggrek, "profilePicture": userprofile/xiaokee.binus@merchant.com.jpg, "location": Kantin Payung, "openTime": 09:00:00],
 "oKdqUi6Jlghrid0WHzFZ": ["name": Nucizz Porsche, "campus": Kemanggisan Anggrek, "closeTime": 17:30, "queueTime": 15, "openTime": 09:00, "location": Kantin Payung, "rating": 3.1, "halal": 1, "profilePicture": userprofile/calvinanacia123@gmail.com.jpg, "phone": +6282183928088, "email": calvinanacia123@gmail.com, "description": This is a new merchant.],
 "2JNYSGGq1fSfQip4o0Nq": ["campus": Kemanggisan Anggrek, "name": Bakmie Effata, "rating": 4.8, "phone": +6281549754138, "email": bakmieffata.binus@merchant.com, "openTime": 09:00:00, "profilePicture": userprofile/bakmieffata.binus@merchant.com.jpg, "closeTime": 17:30:00, "description": This is a new merchant., "location": Kantin Basement, "halal": 1, "queueTime": 10],
 "ccYcA1YUZqjREQb4zcf6": ["email": ceritacinta.binus@merchant.com, "phone": +6287415493248, "openTime": 09:00:00, "halal": 1, "location": Kantin Basement, "closeTime": 17:30:00, "queueTime": 20, "rating": 4.3, "campus": Kemanggisan Anggrek, "description": This is a new merchant., "profilePicture": userprofile/ceritacinta.binus@merchant.com.jpg, "name": Cerita Cinta]]

 Fetched Product data: [
 "hYlsqiHhttN6VICJPxhR": ["price": 23000, "description": Nasi + Ayam + Soup, "thumbnailPicture": product/xiaokee.binus@merchant.com/Nasi Hainam Ayam Fillet.jpg, "totalSale": 0, "name": Nasi Hainam Ayam Fillet, "available": 1],
 "PlzYjOwD5GDArzJyPZUr": ["price": 23000, "available": 1, "totalSale": 0, "description": Nasi + Ayam Roll + Soup, "thumbnailPicture": product/xiaokee.binus@merchant.com/Nasi Hainam Ayam Roll.jpg, "name": Nasi Hainam Ayam Roll],
 "dy9SYaF1LS9Iqz8Rsh6C": ["available": 1, "price": 23000, "thumbnailPicture": product/xiaokee.binus@merchant.com/Nasi Hainam Ayam Penyet.jpg, "name": Nasi Hainam Ayam Penyet, "totalSale": 0, "description": Nasi + Ayam Penyet + Soup],
 "zXs2lHInqtTwjyzIXtUm": ["available": 1, "price": 23000, "thumbnailPicture": product/xiaokee.binus@merchant.com/Nasi Hainam Ayam Panggang.jpg, "name": Nasi Hainam Ayam Panggang, "description": Nasi + Ayam Panggang + Soup, "totalSale": 0],
 "jnREiiW3K7DrkOwvasM4": ["description": Nasi + Donburi + Soup, "totalSale": 0, "available": 1, "thumbnailPicture": product/xiaokee.binus@merchant.com/Nasi Hainam Donburi.jpg, "name": Nasi Hainam Donburi, "price": 23000]]
 
 */
