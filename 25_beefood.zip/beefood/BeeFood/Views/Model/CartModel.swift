//
//  CartModel.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class CartItemModel{
    var menuId: String
    var qty: Int
    
    init(menuId: String, qty: Int) {
        self.menuId = menuId
        self.qty = qty
    }
    
    static func FetchCartItem() -> [CartItemModel]{
        return [
            CartItemModel(menuId: "0", qty: 2),
            CartItemModel(menuId: "1", qty: 1)
        ]
    }
}

class CartModel{
    
    var merchantId: String
    var cartItems: [CartItemModel]
    var notes: String
    
    init(merchantId: String, cartItems: [CartItemModel], notes: String) {
        self.merchantId = merchantId
        self.cartItems = cartItems
        self.notes = notes
    }
    
    static func FetchCart() -> CartModel{
        return CartModel(merchantId: "0", cartItems: CartItemModel.FetchCartItem(), notes: "test Notes")
    }
    
}
