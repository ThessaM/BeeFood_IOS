//
//  GlobalData.swift
//  BeeFood
//
//  Created by prk on 04/12/23.
//

import Foundation

class GlobalData{
    
    static let shared = GlobalData()
    
    static let LocationArray = ["BINUS Kemanggisan", "BINUS Alam Sutera", "BINUS Bandung"];
    static let kemanggisanCampusArray = ["Kemanggisan Anggrek", "Kemanggisan Kijang", "Kemanggisan Syahdan"]
    static var locationSelected: Int = 0
    static let adBannerImages = ["Banner-1", "Banner-2", "Banner-3"]
    static let statusIndexing = ["Cancelled", "Waiting for Confirmation", "onProcess", "Ready for Pickup", "Completed"]
    
    
    
    
//    static var curUserId: String = "0"
    static var isMerchantFetch = false
    static var deviceFCMToken = ""
    static var fetchedMerchants: [MerchantModel] = []
    static var locationFilteredMerchants: [MerchantModel] = []
    static var curUser: UserModel?
    static var curCart: CartModel = CartModel(merchantId: "0", cartItems: [], notes: " ")
    static var curOrder: [OrderModel] = []
    
    
    //FCM
    func sendMessageFCM(merchantToken: String, notifTitle: String, notifBody: String){
        let serverKey = "AAAAaOhAJzA:APA91bGVZP53NZtJXgsZPjEGFxgjQj3Gevs2SQRBOjKRqFdJaH6E7UII_hQ6yUPmd2JqMSn8gZAOvSpeAFeVbeEv3s4Sbsww9c5U079zkvuUMNSLDmy7baHU9GqohNPEYNEIUdAITl1K"
        let fcmToken = merchantToken

        let url = URL(string: "https://fcm.googleapis.com/fcm/send")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("key=\(serverKey)", forHTTPHeaderField: "Authorization")

        let body: [String: Any] = [
            "to": fcmToken as Any,
            "notification": [
                "title": "\(notifTitle)",
                "body": "\(notifBody)"
            ]
            ,
//            "data": [
//                "key1": "value1",
//                "key2": "value2"
//            ]
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle the response
            if let error = error{
                print("MESSAGE ERROR: \(error)")
            }else{
                print("MESSAGE SUCCESS: \(String(describing: response))")
            }
        }.resume()
    }
    
}

extension Notification.Name{
    static let orderAddedFromCart = Notification.Name("orderAddedFromCart")
    
}
