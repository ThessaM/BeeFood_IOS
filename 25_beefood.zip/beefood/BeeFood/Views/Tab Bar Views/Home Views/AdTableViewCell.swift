//
//  AdTableViewCell.swift
//  BeeFood
//
//  Created by prk on 24/11/23.
//

import UIKit

class AdTableViewCell: UITableViewCell {

    @IBOutlet weak var adImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
