//
//  PopularCollectionViewCell.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class PopularCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var merchantImage: UIImageView!
    
    @IBOutlet weak var merchantName: UILabel!
    
    @IBOutlet weak var merchantLocation: UILabel!
    
    var merchant: MerchantModel!{
        didSet{
            self.updatePopView()
        }
    }
    
    func updatePopView(){
        merchantImage.image = merchant.profilePicture
        merchantName.text = merchant.name
        merchantLocation.text = merchant.location
        
        merchantImage.layer.cornerRadius = 5
    }
}

private extension PopularCollectionViewCell{
    
}
