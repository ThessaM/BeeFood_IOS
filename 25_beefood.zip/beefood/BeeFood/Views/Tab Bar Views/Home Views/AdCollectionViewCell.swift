//
//  AdCollectionViewCell.swift
//  BeeFood
//
//  Created by prk on 30/11/23.
//

import UIKit

class AdCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var adImage: UIImageView!
    
    var curAdImage: String! {
        didSet{
            self.updateAdView()
        }
    }
    
    func updateAdView(){
        adImage.image = UIImage(named: curAdImage)
        
//        adImage.layer.cornerRadius = 10.0
//        adImage.layer.masksToBounds = true
    }
    
}

