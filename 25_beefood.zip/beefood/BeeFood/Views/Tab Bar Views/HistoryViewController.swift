//
//  HistoryViewController.swift
//  BeeFood
//
//  Created by prk on 24/11/23.
//

import UIKit

protocol historyOrderDataDelegate: AnyObject{
    func didHistoryDataUpdated(status: Int)
}


class HistoryViewController: UIViewController {
    
    weak var historyDelegate: historyOrderDataDelegate?
    
    //PROFILE IMAGE ------------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var profileImage: RoundedImageView!
    
    @objc func imageTapped(){
        performSegue(withIdentifier: "toProfileFromHistory", sender: self)
    }
    
    //ORDER HISTORY TABLE VIEW  -----------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var OrderHistoryTableView: UITableView!
    var orderHistories: [OrderModel] = []
    var merchants : [MerchantModel] = []
    var isHistoryFetched = false
    
 
    //VIEW LOAD -------------------------------------------------------------------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        //navigation bar
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        NotificationCenter.default.addObserver(self, selector: #selector(orderAdded), name: .orderAddedFromCart, object: nil)
        
        FirebaseService.shared.fetchOrderDataFromFirestore(curUserId: GlobalData.curUser!.id) { fetchedOrderData, orderDataError in
            if let orderDataError = orderDataError{
                print("Fetched Order Data Error: \(orderDataError)")
                return
            }
            
            self.orderHistories = fetchedOrderData!
            self.isHistoryFetched = true
            print("FETCHED ORDER HISTORY: \(self.orderHistories.count)")
            
            if GlobalData.isMerchantFetch{
                self.merchants = GlobalData.fetchedMerchants
                self.setOrderHistoryTable()
            }
            
        }
        
        //profile image
        let gesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        profileImage.addGestureRecognizer(gesture)
        
        //history table
        OrderHistoryTableView.dataSource = self
        OrderHistoryTableView.delegate = self
    }
    
    
    @objc func orderAdded(_notification: Notification){
        FirebaseService.shared.fetchOrderDataFromFirestore(curUserId: GlobalData.curUser!.id) { fetchedOrderData, orderDataError in
            if let orderDataError = orderDataError{
                print("Fetched Order Data Error: \(orderDataError)")
                return
            }
            print("FETCHED ORDER HISTORY DELEGATE")
            self.orderHistories = fetchedOrderData!
            self.setOrderHistoryTable()
        }
    }
    
    deinit{
        NotificationCenter.default.removeObserver(self, name: .orderAddedFromCart, object: nil)
    }
    
    func setOrderHistoryTable(){
        self.isHistoryFetched = true
        self.orderHistories = self.orderHistories.sorted(by: {$0.createTime > $1.createTime})
        self.OrderHistoryTableView.reloadData()
        var passStatus = 0;
        self.orderHistories.forEach { orderItem in
            print("ORDER STATUS: \(orderItem.status)")
            if((orderItem.status > 0) && (orderItem.status < 4) && (orderItem.status >= passStatus)){
                passStatus = orderItem.status
            }
        }
//        print("STATUS: \(passStatus)")
        historyDelegate?.didHistoryDataUpdated(status: passStatus)
    }
    
}

extension HistoryViewController: UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(GlobalData.isMerchantFetch && isHistoryFetched){
            return orderHistories.count
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderHistoryCell", for: indexPath) as! HistoryOrderTableViewCell
        let curOrder = orderHistories[indexPath.row]
        let curMerchant = merchants.first(where: {merch in merch.id == curOrder.merchantId})
        
        cell.merchant = curMerchant
        cell.orderHistory = curOrder
        
        cell.orderCount.text = "\(curOrder.cartItems.count) items"
        
        var orderLists:String = ""
        
        
        
        curOrder.cartItems.forEach{
            orderItem in
            
            let curProduct = curMerchant?.product.first(where: { menuData in
                menuData.id == orderItem.menuId
            })
            
            orderLists.append("\(orderItem.qty) \(curProduct!.name) ")
        }
        
        cell.orderList.text = orderLists
        cell.reorderButtonOutler.isHidden = true
        
        //set status colour
        if(curOrder.status == 4){
            //completed
            cell.orderStatus.text = GlobalData.statusIndexing[4]
            cell.orderStatus.textColor = UIColor.systemGreen
            cell.reorderButtonOutler.isHidden = false
        }else if(curOrder.status == -1){
            //Cancelled
            cell.orderStatus.text = GlobalData.statusIndexing[0]
            cell.orderStatus.textColor = UIColor.systemRed
        }else if(curOrder.status == 1){
            //Waiting for Confirmation
            cell.orderStatus.text = GlobalData.statusIndexing[1]
            cell.orderStatus.textColor = UIColor.systemYellow
        }else if(curOrder.status == 3){
            //Ready for Pickup
            cell.orderStatus.text = GlobalData.statusIndexing[3]
            cell.orderStatus.textColor = UIColor.systemBlue
        }else{
            //onProcess
            cell.orderStatus.text = GlobalData.statusIndexing[2]
            cell.orderStatus.textColor = UIColor.systemOrange
        }
        
        cell.reorderButtonHandler = {
            let alert = UIAlertController(title: "Feature Comming Soon", message: "Wait for updates from us 😘", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(action)
            self.present(alert, animated: true)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let curStatus = orderHistories[indexPath.row].status
        if (curStatus > 0 && curStatus < 4){
            let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PickUpViewController") as! PickUpViewController
            let curOrder = orderHistories[indexPath.row]
            dest.order = curOrder
            dest.pickUpDelegate = self
            dest.merchant = merchants.first(where: { merchantData in
                merchantData.id == curOrder.merchantId
            })
            
            navigationController?.pushViewController(dest, animated: true)
        }
    }
    
}


extension HistoryViewController: homeMerchantDataDelegate{
    
    func didMerchantDataUpdated() {
        merchants = GlobalData.fetchedMerchants
        GlobalData.isMerchantFetch = true
        if OrderHistoryTableView != nil{
            if isHistoryFetched {
                setOrderHistoryTable()
            }
        }
    }
}

extension HistoryViewController: cartOrderAddedDelegate{
    
    //update tiap ada data order yg ditambah
    func didHistoryOrderDataUpdated() {
        FirebaseService.shared.fetchOrderDataFromFirestore(curUserId: GlobalData.curUser!.id) { fetchedOrderData, orderDataError in
            if let orderDataError = orderDataError{
                print("Fetched Order Data Error: \(orderDataError)")
                return
            }
            print("FETCHED ORDER HISTORY DELEGATE FROM CART")
            self.orderHistories = fetchedOrderData!
            self.setOrderHistoryTable()
        }
    }
    
    
}

extension HistoryViewController: confirmPickUpDelegate{
    
    
    func didOrderStatusUpdated() {
        FirebaseService.shared.fetchOrderDataFromFirestore(curUserId: GlobalData.curUser!.id) { fetchedOrderData, orderDataError in
            if let orderDataError = orderDataError{
                print("Fetched Order Data Error: \(orderDataError)")
                return
            }
            print("FETCHED ORDER HISTORY DELEGATE FROM PICKUP")
            self.orderHistories = fetchedOrderData!
            self.setOrderHistoryTable()
        }
    }
    
    
}

