//
//  HistoryOrderTableViewCell.swift
//  BeeFood
//
//  Created by prk on 04/12/23.
//

import UIKit

class HistoryOrderTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var merchantImage: UIImageView!
    
    @IBOutlet weak var merchantName: UILabel!
    
    @IBOutlet weak var merchantRegion: UILabel!
    
    @IBOutlet weak var orderStatus: UILabel!
    
    @IBOutlet weak var orderPrice: UILabel!
    
    
    //CONTROLLER
    
    @IBOutlet weak var orderCount: UILabel!
    
    @IBOutlet weak var orderList: UILabel!
    
    @IBOutlet weak var reorderButtonOutler: UIButton!
    
    var reorderButtonHandler: (() -> Void)?
    
    @IBAction func reorderButtonOnPressed(_ sender: Any) {
        reorderButtonHandler?()
    }
    
    var merchant:MerchantModel!{
        didSet{
            merchantImage.image = merchant.profilePicture
            merchantName.text = merchant.name
            merchantRegion.text = "\(merchant.campus) • "
        }
    }
    
    var orderHistory: OrderModel!{
        didSet{
//            orderStatus.text = orderHistory.status
            orderPrice.text = "Rp. \(orderHistory.totalPrice)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
