//
//  HomeViewController.swift
//  BeeFood
//
//  Created by prk on 24/11/23.
//

import UIKit

class CellClass:UITableViewCell{} //dropdown table class

import FirebaseFirestore


protocol homeMerchantDataDelegate: AnyObject{
    func didMerchantDataUpdated()
}


class HomeViewController: UIViewController {
    
    //PROFILE IMAGE ------------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var profileImage: RoundedImageView!
    
    @objc func imageTapped(){
        performSegue(withIdentifier: "toProfileFromHome", sender: self)
    }
    
    //DROPDOWN TABLE ------------------------------------------------------------------------------------------------------------------------------------
    
    let LocationTableView = UITableView();
    let LocationTransparentView = UIView();
    let LocationArray = GlobalData.LocationArray
    
    @IBOutlet weak var LocationTableViewButton: UIButton!
    
    @IBAction func LocationTVButtonOnPressed(_ sender: UIButton) {
        addLocationTransparentView(frames: LocationTableViewButton.frame)
        //sort merchant list
    }
    
    func addLocationTransparentView(frames: CGRect){
        LocationTransparentView.frame = self.view.frame
        self.view.addSubview(LocationTransparentView)
        
        LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        self.view.addSubview(LocationTableView)
        LocationTableView.layer.cornerRadius = 5
        
        LocationTransparentView.backgroundColor = UIColor.clear
        LocationTableView.reloadData()
        
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(hideLocationTable))
        LocationTransparentView.addGestureRecognizer(tapgesture)
        LocationTransparentView.alpha = 0
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.LocationTransparentView.alpha = 0.5
            self.LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height + 5, width: frames.width, height: CGFloat(self.LocationArray.count * 40))
        }, completion: nil)
    }
    
    @objc private func hideLocationTable(){
        let frames = LocationTableViewButton.frame
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1,options: .curveEaseInOut, animations: {
            self.LocationTransparentView.alpha = 0
            self.LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        }, completion: nil)
    }
    
    func setInitButtonTitle(){
        LocationTableViewButton.setTitle(LocationArray[GlobalData.locationSelected], for: .normal)
        filterMerchantByLocation(location: LocationArray[GlobalData.locationSelected])
    }
    
    func filterMerchantByLocation(location: String){
        if(location.elementsEqual(LocationArray[0])){
            GlobalData.locationFilteredMerchants = GlobalData.fetchedMerchants.filter({ curMerch in
                curMerch.campus == GlobalData.kemanggisanCampusArray[0] || curMerch.campus == GlobalData.kemanggisanCampusArray[1] || curMerch.campus == GlobalData.kemanggisanCampusArray[2]
            })
        }else{
            GlobalData.locationFilteredMerchants = GlobalData.fetchedMerchants.filter({ curMerch in
                curMerch.campus == GlobalData.LocationArray[GlobalData.locationSelected]
            })
        }
        updateMerchantTablesData()
    }
    
    
    
    //AD COLLECTION VIEW ------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var adCollectionView: UICollectionView!
    
    var adImages = GlobalData.adBannerImages
//    var cellScale : CGFloat = 0.6
    
    //STATUS IMAGE -----------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var statusImage: UIImageView!
    
    
    //POPULAR COLLECTION VIEW --------------------------------------------------------------------------------------------------------------------------
    @IBOutlet weak var popularCollectionView: UICollectionView!
    
    var popMerchants: [MerchantModel] = []
    
    //WAITING COLLECTION VIEW --------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var waitingCollectionView: UICollectionView!
    var waitMerchants: [MerchantModel] = []
    
    
    func updateMerchantTablesData(){
        self.popMerchants = GlobalData.locationFilteredMerchants.sorted(by: {$0.rating > $1.rating})
//                self.popMerchants.prefix(4)
        self.waitMerchants = GlobalData.locationFilteredMerchants.sorted(by: {$0.queueTime < $1.queueTime})
//                self.waitMerchants.prefix(4)
        
        self.popularCollectionView.reloadData()
        self.waitingCollectionView.reloadData()
    }
    
    //VIEW DID LOAD -----------------------------------------------------------------------------------------------------------------------------------
    
    weak var homeDelegate: homeMerchantDataDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        
        FirebaseService.shared.fetchMerchantDataFromFirestore { merchantData, merchantError in
            if let merchantError = merchantError{
                print("Error fetching data: \(merchantError)")
            } else {

                GlobalData.fetchedMerchants = merchantData!
                GlobalData.isMerchantFetch = true
                
                self.filterMerchantByLocation(location: self.LocationArray[GlobalData.locationSelected])
                
                self.homeDelegate?.didMerchantDataUpdated()
            }
        }
        

        
        //profile image
        let gesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        profileImage.addGestureRecognizer(gesture)
        
        //Dropdown table 🤯
        LocationTableView.dataSource = self
        LocationTableView.delegate = self
        LocationTableView.register(CellClass.self, forCellReuseIdentifier: "locationCell")
        
        //COLLECTION VIEWS
        adCollectionView.layer.backgroundColor = UIColor.clear.cgColor
        adCollectionView.dataSource = self
        
        popularCollectionView.dataSource = self
        popularCollectionView.delegate = self
        
        waitingCollectionView.dataSource = self
        waitingCollectionView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setInitButtonTitle()
    }
    
    
}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource{
    //TABLE VIEWWWWW ------------------------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //Dropdown
        LocationTableViewButton.setTitle(LocationArray[indexPath.row], for: .normal)
        GlobalData.locationSelected = indexPath.row
        LocationTableViewButton.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        filterMerchantByLocation(location: LocationArray[indexPath.row])
        hideLocationTable()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Dropdown
        return LocationArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Dropdown
        let cell = tableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath)
        cell.textLabel?.text = LocationArray[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //Dropdown
        return 40
    }

}

extension HomeViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if(collectionView.isEqual(adCollectionView)){
            return adImages.count
        }else if(collectionView.isEqual(popularCollectionView)){
            return popMerchants.count
        }else if(collectionView.isEqual(waitingCollectionView)){
            return waitMerchants.count
        }
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        if(collectionView.isEqual(adCollectionView)){
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "adColView", for: indexPath) as! AdCollectionViewCell
            let curImg = adImages[indexPath.item]
            cell.curAdImage = curImg
            return cell
        }else if(collectionView.isEqual(popularCollectionView)){
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "popColView", for: indexPath) as! PopularCollectionViewCell
            let curMerchant = popMerchants[indexPath.item]
            cell.merchant = curMerchant
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "waitColView", for: indexPath) as! PopularCollectionViewCell
            let curMerchant = waitMerchants[indexPath.item]
            cell.merchant = curMerchant
            return cell
        }
        
        
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if(collectionView.isEqual(popularCollectionView)){
            let curMerchant = popMerchants[indexPath.row]
            let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FoodListViewController") as! FoodListViewController
            dest.merchant = curMerchant
            navigationController?.pushViewController(dest, animated: true)
        }else if(collectionView.isEqual(waitingCollectionView)){
            let curMerchant = waitMerchants[indexPath.row]
            let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FoodListViewController") as! FoodListViewController
            dest.merchant = curMerchant
            navigationController?.pushViewController(dest, animated: true)
        }
    
    }
    
   
}

extension HomeViewController: historyOrderDataDelegate{
    
    
    func didHistoryDataUpdated(status: Int) {
        print("STATUS UPDATED")
        if(status == 0){
            //no order
            statusImage.image = UIImage(named: "Order Status-3")
        }else if(status == 1){
            //wait confirm
            statusImage.image = UIImage(named: "Order Status-1")
        }else if(status == 2){
            //on process
            statusImage.image = UIImage(named: "Order Status")
        }else if(status == 3){
            //ready pickup
            statusImage.image = UIImage(named: "Order Status-2")
        }
    }
    
}


extension HomeViewController:searchLocationDelegate{
    
    
    func didLocationDataUpdated() {
        updateMerchantTablesData()
    }
    
}
