//
//  ViewController.swift
//  BeeFood
//
//  Created by prk on 10/23/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


}

