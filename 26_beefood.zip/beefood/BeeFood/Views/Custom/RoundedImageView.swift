//
//  RoundedImageView.swift
//  BeeFood
//
//  Created by prk on 04/12/23.
//

import UIKit

@IBDesignable class RoundedImageView: UIImageView {

    @IBInspectable var borderColor:UIColor = UIColor.white {
        willSet {
            //border putih
            layer.borderColor = newValue.cgColor
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = frame.height/2 //biar lingkaran
        layer.masksToBounds = true
        layer.borderWidth = 1
        layer.borderColor = borderColor.cgColor
    }

}

