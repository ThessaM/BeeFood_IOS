//
//  RoundedImage.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

@IBDesignable class RoundedImage: UIImageView {

    @IBInspectable var borderColor:UIColor = UIColor.white {
        willSet {
            layer.borderColor = newValue.cgColor
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = frame.height/2
        layer.masksToBounds = true
    }

}
