//
//  roundedCornerImageView.swift
//  BeeFood
//
//  Created by Febrico Jonata -- di mac nya rico pak soalnya on 17/12/23.
//

import UIKit

@IBDesignable class RoundedCornerImageView: UIImageView {

    @IBInspectable var borderColor:UIColor = UIColor.white {
        willSet {
            //kasi border putih                  ^
            layer.borderColor = newValue.cgColor
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        //tambah corner
        layer.cornerRadius = 16
        layer.masksToBounds = true
        
    }

}
