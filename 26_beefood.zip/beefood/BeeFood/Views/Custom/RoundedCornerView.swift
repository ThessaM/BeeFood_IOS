//
//  RoundedCornerView.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

@IBDesignable
class RoundedCornerView: UIView {

    override func layoutSubviews() {
        super.layoutSubviews()
        //kasi corner
        layer.cornerRadius = 20
    }

}
