//
//  ChoosePaymentViewController.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

//delegate protocol
protocol ChoosePaymentControllerDelegate: AnyObject {
    func didPaymentSelected(_ reuseIdentifier: String?)
}


class ChoosePaymentViewController: UIViewController, PaymentTableDelegate{
    
    @IBAction func backButtonOnPressed(_ sender: Any) {
        //back
        navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var paymentContainerView: UIView!
    
    
    
    //ACCESSING PAYMENT INSIDE PAYMENT TABLE VIEW CONTROLLER --------------------------------------------------------------------------------------------
    
    var paymentTableViewController: PaymentTableViewController?
    
    //delegate to cartview
    weak var paymentDelegate: ChoosePaymentControllerDelegate?

    
    func didSelectPaymentMethod(_ reuseIdentifier: String?) {
        //delegate notify
        paymentDelegate?.didPaymentSelected(reuseIdentifier)
        navigationController?.popViewController(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //passing delegate
        if let paymentTableView = segue.destination as? PaymentTableViewController {
            paymentTableViewController = paymentTableView
            paymentTableViewController?.delegate = self
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }


}



