//
//  ProfileViewController.swift
//  BeeFood
//
//  Created by prk on 06/12/23.
//

import UIKit
import Firebase

class ProfileViewController: UIViewController {

    
    @IBOutlet weak var username: UILabel!
    
    @IBOutlet weak var userBinusianId: UILabel!
    
    @IBOutlet weak var userImage: RoundedImageView!
    
    
    
    @IBAction func backButtonOnPressed(_ sender: Any) {
        //back
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func logoutOnPressed(_ sender: Any) {
        
        do {
            try Auth.auth().signOut()
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError.localizedDescription)")
        }
        
        
        navigationController?.popToRootViewController(animated: true)
        
        //print("LOGOUT CLICKED")
        //print(navigationController?.viewControllers.count ?? -656)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set labels
        username.text = GlobalData.curUser!.name
        userBinusianId.text = GlobalData.curUser!.binusianId
        
    }
    
    
    
    
    
    

}
