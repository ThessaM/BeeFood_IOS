//
//  FirebaseService.swift
//  BeeFood
//
//  Created by prk on 12/12/23.
//

import FirebaseFirestore
import FirebaseStorage
import UIKit

class FirebaseService {
    
    static let shared = FirebaseService()

    private let db = Firestore.firestore()
    private let storage = Storage.storage()

    
    // MERCHANT ----------------------------------------------------------------------------------------------------------------
    func fetchDataFromFirestore(completion: @escaping ([String: Any]?, Error?) -> Void) {
        db.collection("merchant").getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                var data = [String: Any]()
                for document in querySnapshot!.documents {
                    data[document.documentID] = document.data()
                }
                completion(data, nil)
            }
        }
    }
    
    func fetchMerchantDataFromFirestore(completion: @escaping ([MerchantModel]?, Error?) -> Void) {
        db.collection("merchant").getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                var finalMerchantData: [MerchantModel] = []
                let dispatchGroup = DispatchGroup()

                for document in querySnapshot!.documents {
                    let data = document.data()

                    guard let profilePicturePath = data["profilePicture"] as? String else {
                        continue
                    }

                    dispatchGroup.enter()

                    self.fetchImageFromStorage(imagePath: profilePicturePath) { imageData, imageError in
                        if let imageError = imageError {
                            print("Error fetching image data: \(imageError)")
                            dispatchGroup.leave()
                        } else {
                            let merchantId = document.documentID
                            self.fetchMenuFromMerchant(merchantId: merchantId) { menuData, menuError in
                                if let menuError = menuError {
                                    print("Error fetching menu data: \(menuError)")
                                } else {
                                    if let imageData = imageData,
                                       let name = data["name"] as? String,
                                       let email = data["email"] as? String,
                                       let phone = data["phone"] as? String,
                                       let description = data["description"] as? String,
                                       let campus = data["campus"] as? String,
                                       let location = data["location"] as? String,
                                       let openTime = data["openTime"] as? String,
                                       let closeTime = data["closeTime"] as? String,
                                       let halal = data["halal"] as? Bool,
                                       let rating = data["rating"] as? Double,
                                       let queueTime = data["queueTime"] as? Int {
                                        
                                        let FCMToken = data["FCMToken"] as? String
                                        let merchantModel = MerchantModel(
                                            id: merchantId,
                                            name: name,
                                            email: email,
                                            phone: phone,
                                            profilePicture: imageData,
                                            description: description,
                                            campus: campus,
                                            location: location,
                                            openTime: openTime,
                                            closeTime: closeTime,
                                            halal: halal,
                                            rating: rating,
                                            queueTime: queueTime,
                                            product: menuData ?? [],
                                            FCMToken: FCMToken ?? ""
                                        )

                                        finalMerchantData.append(merchantModel)
                                    } else {
                                        print("Error: Unable to create MerchantModel due to missing or invalid data")
                                    }
                                }
                                dispatchGroup.leave() // Move leave inside the completion handler of fetchMenuFromMerchant
                            }
                        }
                    }
                }

                dispatchGroup.notify(queue: .main) {
                    completion(finalMerchantData, nil)
                }
            }
        }
    }


    

    
    func fetchMerchantIDsFromFirestore(completion: @escaping ([String]?, Error?) -> Void) {
        db.collection("merchant").getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                let documentIDs = querySnapshot?.documents.map{ $0.documentID} ?? []
                completion(documentIDs, nil)
            }
        }
    }
    
    
    
    func fetchMenuFromMerchant(merchantId: String, completion: @escaping ([MenuModel]?, Error?) -> Void) {
        
        let menuCollection = db.collection("merchant").document(merchantId).collection("product")
        
        menuCollection.getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                var menuData: [MenuModel] = []
                let dispatchGroup = DispatchGroup()

                for document in querySnapshot!.documents {
                    let data = document.data()

                    guard let thumbnailPicturePath = data["thumbnailPicture"] as? String else {
                        continue
                    }

                    dispatchGroup.enter()

                    self.fetchImageFromStorage(imagePath: thumbnailPicturePath) { imageData, imageError in
                        if let imageError = imageError {
                            print("Error fetching image data: \(imageError)")
                        } else {
                            // Create a MenuModel object with the fetched image data
                            
                            
                            let menuModel = MenuModel(
                                id: document.documentID,
                                name: data["name"] as? String ?? "",
                                description: data["description"] as? String ?? "",
                                price: data["price"] as? Int ?? 0,
                                thumbnailPicture: imageData ?? UIImage(), // Use the fetched image data
                                totalSale: data["totalSale"] as? Int ?? 0,
                                available: data["available"] as? Bool ?? true
                            )

                            menuData.append(menuModel)
                        }

                        dispatchGroup.leave()
                    }
                }

                dispatchGroup.notify(queue: .main) {
                    completion(menuData, nil)
                }
            }
        }
    }
    
    
    
    //USERRRRRR -----------------------------------------------------------------------------------------------------------------------------
    
    //--create user udh di register
    
    func fetchUserFromFirestoreByUid(uid: String, completion: @escaping (UserModel?, Error?) -> Void) {
        db.collection("user").document(uid).getDocument { document, error in
            if let error = error {
                print("Error fetching user data: \(error.localizedDescription)")
                completion(nil, error)
            } else {
                if let document = document, document.exists {
                    let userData = document.data()

                    if let name = userData?["name"] as? String,
                       let binusianId = userData?["binusianID"] as? String,
                       let email = userData?["email"] as? String,
                       let imageUrl = userData?["profilePicture"] as? String {

                        // Create the UserModel
                        let userData = UserModel(id: uid, name: name, binusianId: binusianId, email: email, image: UIImage(named: "BeeFoodLogo")!, FCMToken: "")

                        GlobalData.curUser = userData
                        //print("USER SET")
                        //print("User Data: \(userData)")
                        print(imageUrl)

                        completion(userData, nil)
                    }
                } else {
                    print("User document does not exist")
                    completion(nil, error)
                }
            }
        }
    }
    
    func addUserDataToFirestore(user:UserModel, uid: String, completion: @escaping (Error?) -> Void){
        let userData = [
            "name": user.name,
            "email": user.email,
            "binusianID": user.binusianId,
            "profilePicture": "",
            "FCMToken": user.FCMToken
        ]

        // Store additional data in Firestore
        db.collection("user").document(uid).setData(userData) { error in
            if let error = error {
                print("Error storing user data: \(error.localizedDescription)")
                completion(error)
            }
            completion(nil)
        }
    }

    
    //ORDER HISTORYYYYY --------------------------------------------------------------------------------------------------------------------
    
    //get history
    func fetchOrderDataFromFirestore(curUserId: String, completion: @escaping ([OrderModel]?, Error?) -> Void) {
        db.collection("order").getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                var orderModels: [OrderModel] = []
                print("COLLECTION ORDER CHECKPOINT")
                var counter = 0
                
                for document in querySnapshot!.documents {
                    let orderData = document.data()

                    // order ID
                    let orderId = document.documentID

                    // cart items subcollection
                    let cartItemsCollectionRef = self.db.collection("order").document(orderId).collection("orderItems")
                    var cartItems: [CartItemModel] = []

                    cartItemsCollectionRef.getDocuments { (cartItemsSnapshot, cartItemsError) in
                        if let cartItemsError = cartItemsError {
                            completion(nil, cartItemsError)
                            return
                        }

                        for cartItemDocument in cartItemsSnapshot!.documents {

                            let cartItemData = cartItemDocument.data()

                            // subCollection
                            let cartItem = CartItemModel(
                                menuId: cartItemData["productReferenceID"] as? String ?? "",
                                qty: cartItemData["quantity"] as? Int ?? 0
                            )

                            cartItems.append(cartItem)
                        }

                        // Create the OrderModel + subcollection
                        if let createTime = orderData["createTime"] as? Timestamp,
                           let merchantId = orderData["merchantReferenceID"] as? String,
                           let paymentMethod = orderData["payment"] as? String,
                           let pickUpTime = orderData["pickupTime"] as? Timestamp,
                           let status = orderData["status"] as? Int,
                           let totalPrice = orderData["totalPrice"] as? Int,
                           let userId = orderData["userReferenceID"] as? String {
                            
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "HH:mm"

                            let orderModel = OrderModel(
                                id: orderId,
                                userId: userId,
                                merchantId: merchantId,
                                cartItems: cartItems,
                                payment: paymentMethod,
                                totalPrice: totalPrice,
                                status: status,
                                pickUpTime: dateFormatter.string(from: pickUpTime.dateValue()),
                                createTime: dateFormatter.string(from: createTime.dateValue())
                            )
                            

                            if(orderModel.userId == curUserId){
                                orderModels.append(orderModel)
                            }
                            
                            counter+=1
                            
                        }else{
                            print("Create order model error")
                        }
                        
                        if counter == querySnapshot!.documents.count {
                            completion(orderModels, nil)
                        }
                    }
                }
            }
        }
    }

    
    //Update Status Order
    func updateOrderStatus(orderId: String, newStatus: Int, completion: @escaping (Error?) -> Void) {
        
        let orderCollectionRef = db.collection("order")
        let orderDocumentRef = orderCollectionRef.document(orderId)
        //update status
        orderDocumentRef.updateData(["status": newStatus]) { error in
            if let error = error {
                print("Error updating order status: \(error.localizedDescription)")
                completion(error)
            } else {
                print("Order status updated successfully")
                completion(nil)
            }
        }
    }
    
    
    func addOrderDataToFirestore(orderData: [String: Any], completion: @escaping (Error?) -> Void){
        

        let orderReference = db.collection("order").document()
        orderReference.setData(orderData){error in
            if let error = error{
                print("Error storing order data: \(error.localizedDescription)")
                completion(error)
            }
            
            for cartItem in GlobalData.curCart.cartItems {
                let subcollectionData = [
                    "productReferenceID": cartItem.menuId,
                    "quantity": cartItem.qty
                ]

                // Add subcollection
                orderReference.collection("orderItems").addDocument(data: subcollectionData) { subcollectionError in
                    if let subcollectionError = subcollectionError {
                        print("Error storing subcollection data: \(subcollectionError.localizedDescription)")
                        completion(subcollectionError)
                    }
                }
            }
            //print("ORDER DATA SAVED SUCCESSFULLY")
            //delete item in cart
            GlobalData.curCart.cartItems.removeAll()
            completion(nil)
        }
    }

    
    // get IMAGEEEEEEEEE -------------------------------------------------------------------------------------------------------------------

    func fetchImageFromStorage(imagePath: String, completion: @escaping (UIImage?, Error?) -> Void) {
        let storageRef = storage.reference()
        let imageRef = storageRef.child(imagePath)

        imageRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
            if let error = error {
                completion(nil, error)
            } else {
                if let imageData = data {
                    let image = UIImage(data: imageData)
                    completion(image, nil)
                }
            }
        }
    }
}

