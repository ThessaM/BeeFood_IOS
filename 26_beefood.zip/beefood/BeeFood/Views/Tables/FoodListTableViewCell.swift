//
//  FoodListTableViewCell.swift
//  BeeFood
//
//  Created by prk on 08/12/23.
//

import UIKit

class FoodListTableViewCell: UITableViewCell {
    
    
    //delegate data passing
    weak var delegate: TableViewDelegate?
    
    
    @IBOutlet weak var foodImage: UIImageView!
    
    @IBOutlet weak var foodNameLabel: UILabel!
    
    @IBOutlet weak var foodDescLabel: UILabel!
    
    @IBOutlet weak var foodPriceLabel: UILabel!
    
    @IBOutlet weak var foodQtyLabel: UILabel!
    
    @IBOutlet weak var stepper: UIStepper!
    

    
    @IBAction func qtyStepper(_ sender: UIStepper) {
        //get value
        let newQty = Int(sender.value)
        foodQtyLabel.text = "Qty: \(newQty)"
        
        if let data = productInd {
            //notifier
            delegate?.didSelectItem(withData: data, qty: newQty)
        }
    }
    
    var productInd:Int?
    var merchantId: String?
    
    var foodItem:MenuModel!{
        didSet{
            //set labels
            foodImage.image = foodItem.thumbnailPicture
            foodNameLabel.text = foodItem.name
            foodDescLabel.text = foodItem.description
            foodPriceLabel.text = "Rp. \(foodItem.price)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}

protocol TableViewDelegate: AnyObject {
    func didSelectItem(withData ind: Int, qty: Int)
}
