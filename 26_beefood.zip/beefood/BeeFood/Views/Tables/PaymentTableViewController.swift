//
//  PaymentTableViewController.swift
//  BeeFood
//
//  Created by prk on 09/12/23.
//

import UIKit

protocol PaymentTableDelegate: AnyObject {
    func didSelectPaymentMethod(_ reuseIdentifier: String?)
}


class PaymentTableViewController: UITableViewController {


    //DELEGATE FUNCTION TO PARENT VIEW CONTROLLER --------------------------------------------------------------------------------------------
    
    weak var delegate: PaymentTableDelegate?
    
    //VIEW TABLE --------------------------------------------------------------------------------------------------------------------------
    var selectedPaymentMethod: String?
    
    func getselectedPaymentMethod() -> String? {
        return selectedPaymentMethod
    }


    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //kalo di select, passing data ke view controller
        if let cell = tableView.cellForRow(at: indexPath) {
            selectedPaymentMethod = cell.reuseIdentifier
            delegate?.didSelectPaymentMethod(selectedPaymentMethod)
        }
    }
    
    
    //DEFAULT TABLE VIEW CONTROLLER --------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }


}

