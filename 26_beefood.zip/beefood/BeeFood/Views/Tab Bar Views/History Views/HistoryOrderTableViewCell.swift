//
//  HistoryOrderTableViewCell.swift
//  BeeFood
//
//  Created by prk on 04/12/23.
//

import UIKit

class HistoryOrderTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var merchantImage: UIImageView!
    
    @IBOutlet weak var merchantName: UILabel!
    
    @IBOutlet weak var merchantRegion: UILabel!
    
    @IBOutlet weak var orderStatus: UILabel!
    
    @IBOutlet weak var orderPrice: UILabel!
    
    
    //CONTROLLER ----------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var orderCount: UILabel!
    
    @IBOutlet weak var orderList: UILabel!
    
    @IBOutlet weak var reorderButtonOutler: UIButton!
    
    var reorderButtonHandler: (() -> Void)?
    
    //reorder funtion :0
    @IBAction func reorderButtonOnPressed(_ sender: Any) {
        reorderButtonHandler?()
    }
    
    var merchant:MerchantModel!{
        didSet{
            //set labels
            merchantImage.image = merchant.profilePicture
            merchantName.text = merchant.name
            merchantRegion.text = "\(merchant.campus) • "
        }
    }
    
    var orderHistory: OrderModel!{
        didSet{
            //set labels
            orderPrice.text = "Rp. \(orderHistory.totalPrice)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
