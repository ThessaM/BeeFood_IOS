//
//  MainTabBarViewController.swift
//  BeeFood
//
//  Created by prk on 12/16/23.
//

import UIKit

class MainTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //delegate home n search
        if let homeVC = viewControllers?[0] as? HomeViewController,
           let searchVC = viewControllers?[1] as? SearchViewController {
            homeVC.homeDelegate = searchVC
            searchVC.searchDelegate = homeVC
        }
        
        //delegate home n history
        if let homeVC = viewControllers?[0] as? HomeViewController,
           let historyVC = viewControllers?[2] as? HistoryViewController {
            historyVC.historyDelegate = homeVC
        }
        
    }
    


}
