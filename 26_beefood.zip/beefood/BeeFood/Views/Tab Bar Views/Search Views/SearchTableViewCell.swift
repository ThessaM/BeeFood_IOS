//
//  SearchTableViewCell.swift
//  BeeFood
//
//  Created by prk on 04/12/23.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    
    @IBOutlet weak var merchantImage: UIImageView!
    @IBOutlet weak var merchantName: UILabel!
    @IBOutlet weak var merchantLocation: UILabel!
    @IBOutlet weak var merchantTime: UILabel!
    @IBOutlet weak var merchantRating: UILabel!
    
    
    var merchant:MerchantModel!{
        didSet{
            //set labels
            merchantImage.image = merchant.profilePicture
            merchantLocation.text = "\(merchant.location) • "
            merchantName.text = merchant.name
            merchantTime.text = "\(merchant.queueTime) m"
            merchantRating.text = "⭐️ \(merchant.rating)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
