//
//  SearchViewController.swift
//  BeeFood
//
//  Created by prk on 24/11/23.
//

import UIKit

protocol searchLocationDelegate: AnyObject{
    func didLocationDataUpdated()
}

class SearchViewController: UIViewController {
    
    //delegate
    weak var searchDelegate: searchLocationDelegate?
    
    
    //PROFILE IMAGE ------------------------------------------------------------------------------------------------------------------------------------
    
    @IBOutlet weak var profileImage: RoundedImageView!
    
    @objc func imageTapped(){
        performSegue(withIdentifier: "toProfileFromSearch", sender: self)
    }
    
    
    //DROPDOWN TABLE ------------------------------------------------------------------------------------------------------------------------------------
    
    let LocationTableView = UITableView();
    let LocationTransparentView = UIView();
    let LocationArray = GlobalData.LocationArray
    
    
    @IBOutlet weak var LocationTableViewButton: UIButton!
    
    @IBAction func LocationTVButtonOnPressed(_ sender: Any) {
        addLocationTransparentView(frames: LocationTableViewButton.frame)
    }
    
    func addLocationTransparentView(frames: CGRect){
        LocationTransparentView.frame = self.view.frame
        self.view.addSubview(LocationTransparentView)
        
        LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        self.view.addSubview(LocationTableView)
        LocationTableView.layer.cornerRadius = 5
        
        LocationTransparentView.backgroundColor = UIColor.clear
        LocationTableView.reloadData()
        
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(hideLocationTable))
        LocationTransparentView.addGestureRecognizer(tapgesture)
        LocationTransparentView.alpha = 0
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.LocationTransparentView.alpha = 0.5
            self.LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height + 5, width: frames.width, height: CGFloat(self.LocationArray.count * 40))
        }, completion: nil)
    }
    
    @objc private func hideLocationTable(){
        let frames = LocationTableViewButton.frame
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1,options: .curveEaseInOut, animations: {
            self.LocationTransparentView.alpha = 0
            self.LocationTableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        }, completion: nil)
    }
    
    func setInitButtonTitle(){
        LocationTableViewButton.setTitle(LocationArray[GlobalData.locationSelected], for: .normal)
        filterMerchantByLocation(location: LocationArray[GlobalData.locationSelected])
    }
    
    func filterMerchantByLocation(location: String){
        if(location.elementsEqual(LocationArray[0])){
            GlobalData.locationFilteredMerchants = GlobalData.fetchedMerchants.filter({ curMerch in
                curMerch.campus == GlobalData.kemanggisanCampusArray[0] || curMerch.campus == GlobalData.kemanggisanCampusArray[1] || curMerch.campus == GlobalData.kemanggisanCampusArray[2]
            })
        }else{
            GlobalData.locationFilteredMerchants = GlobalData.fetchedMerchants.filter({ curMerch in
                curMerch.campus == GlobalData.LocationArray[GlobalData.locationSelected]
            })
        }
        
        merchants = GlobalData.locationFilteredMerchants
        searchListTableView.reloadData()

    }
    
    
    //SEARCH --------------------------------------------------------------------------------------------------------------------------------------------
    @IBOutlet weak var searchTextField: UITextField!
 
    
    //SEARCH LIST TABLE VIEW  --------------------------------------------------------------------------------------------------------------------------
    
    
    @IBOutlet weak var searchListTableView: UITableView!
    var merchants: [MerchantModel] = []
    
    
    //VIEW LOAD -----------------------------------------------------------------------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        //profile image
        let gesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        profileImage.addGestureRecognizer(gesture)
        
        //Dropdown table 🤯
        LocationTableView.dataSource = self
        LocationTableView.delegate = self
        LocationTableView.register(CellClass.self, forCellReuseIdentifier: "locationCell")
        
        
        //SEARCH TextField
        searchTextField.setUpImage(imageName: "magnifyingglass", on: .left)
        searchTextField.delegate = self
        
        //Search TABLE VIEW
        searchListTableView.dataSource = self
        searchListTableView.delegate = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setInitButtonTitle()
    }

}

//TABLE VIEWWWWW ------------------------------------------------------------------------------------------------------------------------------------

extension SearchViewController: UITableViewDelegate, UITableViewDataSource{
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(tableView.isEqual(LocationTableView)){
            //Dropdown
            LocationTableViewButton.setTitle(LocationArray[indexPath.row], for: .normal)
            GlobalData.locationSelected = indexPath.row
            LocationTableViewButton.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
            hideLocationTable()
            filterMerchantByLocation(location: LocationArray[indexPath.row])
            searchDelegate?.didLocationDataUpdated()
        }else{
            //search cell
            let curMerchant = merchants[indexPath.row]
            let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FoodListViewController") as! FoodListViewController
            dest.merchant = curMerchant
            navigationController?.pushViewController(dest, animated: true)
        }
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(tableView.isEqual(LocationTableView)){
            //Dropdown
            return LocationArray.count
        }else{
            //search list Table view
            return merchants.count
        }
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if(tableView.isEqual(searchListTableView)){
            //search list Table view
            let cell = tableView.dequeueReusableCell(withIdentifier: "searchCell", for: indexPath) as! SearchTableViewCell
            let curMerchant = merchants[indexPath.row]
            cell.merchant = curMerchant
            return cell
            
        }else{ //dropdown
            let cell = tableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath)
            cell.textLabel?.text = LocationArray[indexPath.row]
            
            return cell
        }
        
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //Dropdown
        if(tableView.isEqual(LocationTableView)){
            return 40
        }else{
            return tableView.rowHeight
        }
    }

}


extension SearchViewController: homeMerchantDataDelegate{
    
    //update data per location
    func didMerchantDataUpdated() {
        merchants = GlobalData.locationFilteredMerchants
        if let searchList = searchListTableView{
            searchList.reloadData()
        }
        
    }
    
}


//SEARCH TF ------------------------------------------------------------------------------

enum TextFieldImageSide {
    case left
    case right
}

extension UITextField {
    func setUpImage(imageName: String, on side: TextFieldImageSide) {
        let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 20, height: 20))
        if let imageWithSystemName = UIImage(systemName: imageName) {
            imageView.image = imageWithSystemName
            imageView.tintColor = UIColor.black
        } else {
            imageView.image = UIImage(named: imageName)
        }
        
        let imageContainerView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        imageContainerView.addSubview(imageView)
        
        switch side {
        case .left:
            leftView = imageContainerView
            leftViewMode = .always
        case .right:
            rightView = imageContainerView
            rightViewMode = .always
        }
    }
}

extension SearchViewController: UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? ""

        if(currentText.elementsEqual("") || currentText.isEmpty){
            merchants = GlobalData.locationFilteredMerchants
            searchListTableView.reloadData()
        }else{
//            Filter
            let filteredList = GlobalData.locationFilteredMerchants.filter { $0.name.lowercased().contains(currentText.lowercased()) }
            merchants = filteredList
            searchListTableView.reloadData()
        }
        
        return true
    }
    
    
}
