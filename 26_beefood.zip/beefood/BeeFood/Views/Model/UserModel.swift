//
//  UserModel.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class UserModel{
    
    var id: String
    var name: String
    var binusianId: String
    var email: String
    var image: UIImage
    var FCMToken: String
    
    init(id: String, name: String, binusianId: String, email: String, image: UIImage, FCMToken: String) {
        self.id = id
        self.name = name
        self.binusianId = binusianId
        self.email = email
        self.image = image
        self.FCMToken = FCMToken
    }
    
}
