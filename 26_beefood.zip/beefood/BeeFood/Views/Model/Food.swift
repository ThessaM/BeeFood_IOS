//
//  Food.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class
