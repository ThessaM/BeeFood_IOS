//
//  HistoryModel.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class OrderModel{
    
    var id: String
    var userId: String
    var merchantId: String
    var cartItems: [CartItemModel]
    var payment: String
    var totalPrice: Int
    var status: Int
    var pickUpTime: String
    var createTime: String
    
    init(id: String, userId: String, merchantId: String, cartItems: [CartItemModel], payment: String, totalPrice: Int, status: Int, pickUpTime: String, createTime: String) {
        self.id = id
        self.userId = userId
        self.merchantId = merchantId
        self.cartItems = cartItems
        self.payment = payment
        self.totalPrice = totalPrice
        self.status = status
        self.pickUpTime = pickUpTime
        self.createTime = createTime
    }
    
    
    //DUMMY DATA ---------------------------------------------------------------------------------------------------------------------------------
    static func FetchOrderHistory() -> [OrderModel]{
        return [
            OrderModel(id: "order1", userId: "user1", merchantId: "0", cartItems: [CartItemModel(menuId: "food1", qty: 5)], payment: "Ovo", totalPrice: 116300, status: 2, pickUpTime: "09.00", createTime: "08.00"),
            OrderModel(id: "order2", userId: "user1", merchantId: "1", cartItems: [CartItemModel(menuId: "food0", qty: 1), CartItemModel(menuId: "food3", qty: 2)], payment: "Ovo", totalPrice: 97750, status: 3, pickUpTime: "12.00", createTime: "11.00"),
            OrderModel(id: "order3", userId: "user1", merchantId: "2", cartItems: [CartItemModel(menuId: "food4", qty: 2)], payment: "Ovo", totalPrice: 34000, status: 4, pickUpTime: "03.00", createTime: "02.00")
        ]
    }
}
