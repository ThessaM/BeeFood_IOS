//
//  MenuModel.swift
//  BeeFood
//
//  Created by prk on 01/12/23.
//

import UIKit

class MenuModel{
    
    var id: String
    var name: String
    var description: String
    var price: Int
    var thumbnailPicture: UIImage
    var totalSale: Int
    var available: Bool
    
    init(id: String, name: String, description: String, price: Int, thumbnailPicture: UIImage, totalSale: Int, available: Bool) {
        self.id = id
        self.name = name
        self.description = description
        self.price = price
        self.thumbnailPicture = thumbnailPicture
        self.totalSale = totalSale
        self.available = available
    }
    
    
    
    
    //DUMMY DATA ---------------------------------------------------------------------------------------------------------------------------------
    
    static func FetchMenu() -> [MenuModel]{
        return [
            MenuModel(id: "0", name: "food 1", description: "makan apa aja", price: 20000, thumbnailPicture: UIImage(named: "Merchant-0")!, totalSale: 21, available: true),
            MenuModel(id: "1", name: "food 2", description: "data dummy", price: 23000, thumbnailPicture: UIImage(named: "Merchant-2")!, totalSale: 1, available: true)
        ]
    }
    
    static func FetchMenu2() -> [MenuModel]{
        return [
            MenuModel(id: "3", name: "food 3", description: "dumyyyyyyyyy", price: 40000, thumbnailPicture: UIImage(named: "Merchant-1")!, totalSale: 11, available: true),
            MenuModel(id: "4", name: "food 4", description: "capeeeeeeee", price: 73000, thumbnailPicture: UIImage(named: "Merchant-4")!, totalSale: 2, available: true)
        ]
    }
    
}
